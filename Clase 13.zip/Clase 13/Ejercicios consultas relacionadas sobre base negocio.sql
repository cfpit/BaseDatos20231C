-- Ejercicios sobre consultas relacionadas Base Negocio

 -- 1) Listar la cantidad de clientes que hicieron alguna compra en 
 -- el segundo semestre de 2017. 

  -- 2) Informar la cantidad de compras por cliente. Informar el 
-- nombre y apellido en una única columna de dichos clientes. 
-- Ordenar por cantidad de compras en forma descendente.

  -- 3) Informar las ventas por artículo. Cuál es el artículo 
-- más comprado? Ordenar por cantidad de ventas del más vendido 
-- al menos vendido.

-- 4) Listar nombre y apellido de los clientes que compraron pantalones.
-- Indicar cuando lo compraron y cuanto pagaron.