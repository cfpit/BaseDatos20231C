-- subconsultas = subselect = subquery = consultas anidadas

-- escalar
select max(price) from titles;

-- lista
select pubdate as 'fecha de publicacion' from titles;

-- tabla
select * from titles;

-- subconsultas que devuelven escalares
-- listar nombre y apellido del empleado de mayor antiguedad
select	concat(fname,' ',lname) empleado 
from	employee
where	hire_date = (select min(hire_date) from employee);

-- listar nombre, apellido y telefono del autor 
-- que escribio el ultimo libro publicado
select		concat(a.au_fname,' ',a.au_lname) autor,
			a.phone telefono,
            t.pubdate
from		authors a
inner join	titleauthor ta on a.au_id = ta.au_id
inner join	titles t on ta.title_id = t.title_id
where		t.pubdate = (select max(pubdate) from titles);


