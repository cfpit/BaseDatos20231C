-- 41. Listar el nombre de los libros junto a su categoría de precio. 
-- La categoría de precio se calcula de la siguiente manera: Si el 
-- precio está entre 0 y 10 la categoría es Económica. Si la categoría 
-- está entre 10 Y 20, Normal y si su valor es mayor a 20 la categoría 
-- es Caro. Colocar un apodo a las dos columnas. 
select	title libro,
		price precio,
        (case
			when price < 10 then 'Economica'
            when price between  10 and 20 then 'Normal'
            when price  > 20 then 'Cara'
            else 'Sin categorizar'
        end) as categoria
from	titles;




-- 43. Listar la mitad de los empleados. 
SELECT * FROM employee LIMIT 3 , 15;

SET @inicio=0; SET @cantidadRegistros=(select (count(*) div 2 + 1) from employee);
PREPARE sentencia FROM 'SELECT * FROM employee LIMIT ? , ?';
EXECUTE sentencia USING @inicio, @cantidadRegistros;

select * from employee;

/*
47.	Listar la cantidad de libros vendidos por cada tienda, sólo de aquellas tiendas que su cantidad 
de venta sea mayor al promedio de venta general. 
*/
select		st.stor_name tienda,
			sum(s.qty) ventas
from		stores st
inner join	sales s on st.stor_id = s.stor_id
group by	st.stor_name
having		sum(s.qty) > (
							select 	sum(qty)/count(distinct stor_id) 
                            from 	sales
						 );

-- promedio = 358 / 6 = 58 ventas x libreria

/*
50.	Listar título del libro, categoría de precio, precio unitario y cantidad 
ejemplares vendidos. Mostrar sólo aquellos libros que sean económicos y cuya 
cantidad de ejemplares vendidos sea mayor a cero. Se deben apodar las columnas 
de la siguiente manera: 'Tít", "Cat", "Pr", "Cant". La categoría de los precios 
es la misma del ejercicio 41.
*/
SELECT	*
FROM		(	select		title libro,
							price precio,
							qty ventas,
							(case
								when price < 10 then 'Economica'
								when price between  10 and 20 then 'Normal'
								when price  > 20 then 'Cara'
								else 'Sin categorizar'
							end) as categoria
				from		titles t
				inner join 	sales s on t.title_id = s.title_id
				where		s.qty > 0
		   ) as miTabla
WHERE		miTabla.categoria = 'Economica';


-- 49. Mostrar el nombre de los libros junto a su categoría de precio de 
-- aquellos libros que son categorizados como "Normal". La categoría de 
-- los precios es la misma del ejercicio 41.
SELECT	*
FROM		(	select		title libro,
							price precio,
							(case
								when price < 10 then 'Economica'
								when price between  10 and 20 then 'Normal'
								when price  > 20 then 'Cara'
								else 'Sin categorizar'
							end) as categoria
				from		titles t
				
		   ) as miTabla
WHERE		miTabla.categoria = 'Normal';

/*
44.	Listar todos los libros vendidos, su nombre y la cantidad vendida por cada uno. 
Los apodos para las columnas son las siguientes: "Código del libro", "Nombre del 
libro" y "Cantidad vendida".
*/
select		t.title_id codigo,
			t.title libro,
			s.qty ventas
from		titles t 
inner join	sales s on t.title_id = s.title_id
order by 	3 desc;

-- 45.	Listar todos los libros cuyo precio sea inferior al precio promedio de 
-- todos los libros. 
select		*
from		titles
where		price < (select avg(price) from titles)
order by	price desc;

-- uso de predicados
create database predicados;

use predicados;

create table productos(codigo int, precio float);
create table facturas(codigo int, monto float);

insert into productos values(1,100),(2,200),(3,300),(4,1000);
insert into facturas values(1,300),(2,600),(3,500),(4,200);

-- listar los productos cuyo precio supere todos los montos facturados(no se venden)
select	*
from	productos
-- where	precio > all (select monto from facturas);
-- where	precio <> all (select monto from facturas);
where	precio > any (select monto from facturas);
        
        
        
        
        
        